'use strict';


/**
 * Find Ru2 by ID
 * Returns a single Ru2
 *
 * ru2Id Integer ID of ru2 to return
 * returns Ru2
 **/
exports.getRu2ById = function(ru2Id) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "UnsanctionFlg" : 1,
  "Customer" : "Customer",
  "CommentS" : "CommentS",
  "F020" : "F020",
  "PointPercent" : 1,
  "F021" : 4,
  "F022" : "F022",
  "F001" : "F001",
  "F023" : "F023",
  "F002" : "F002",
  "F024" : "F024",
  "F003" : "F003",
  "F025" : "F025",
  "F004" : "F004",
  "F005" : "F005",
  "F006" : "F006",
  "F007" : 0,
  "CommentB" : "CommentB",
  "F008" : 6,
  "F009" : 1,
  "F010" : 5,
  "OKDiv" : 7,
  "F011" : 5,
  "F012" : 2,
  "F013" : 7,
  "F014" : 9,
  "F015" : "F015",
  "F016" : 3,
  "F017" : 2,
  "OKKeepTomCD" : "OKKeepTomCD",
  "F018" : "F018",
  "F019" : "F019",
  "Worker1" : "Worker1",
  "Worker2" : "Worker2",
  "Worker3" : "Worker3",
  "SBGroupDiv" : 1,
  "OKUsedTomCD" : "OKUsedTomCD"
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

