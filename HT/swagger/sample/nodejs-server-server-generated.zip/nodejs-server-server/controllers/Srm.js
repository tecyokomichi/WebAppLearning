'use strict';

var utils = require('../utils/writer.js');
var Srm = require('../service/SrmService');

module.exports.getSrmById = function getSrmById (req, res, next) {
  var srmId = req.swagger.params['srmId'].value;
  Srm.getSrmById(srmId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.srmGET = function srmGET (req, res, next) {
  var code = req.swagger.params['code'].value;
  var tomKanaCode = req.swagger.params['tomKanaCode'].value;
  Srm.srmGET(code,tomKanaCode)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
