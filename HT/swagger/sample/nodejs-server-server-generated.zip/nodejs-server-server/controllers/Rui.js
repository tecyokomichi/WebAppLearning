'use strict';

var utils = require('../utils/writer.js');
var Rui = require('../service/RuiService');

module.exports.getRuiById = function getRuiById (req, res, next) {
  var ruiId = req.swagger.params['ruiId'].value;
  Rui.getRuiById(ruiId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
