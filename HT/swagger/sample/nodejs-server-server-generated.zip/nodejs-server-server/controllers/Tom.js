'use strict';

var utils = require('../utils/writer.js');
var Tom = require('../service/TomService');

module.exports.getTomById = function getTomById (req, res, next) {
  var tomId = req.swagger.params['tomId'].value;
  Tom.getTomById(tomId)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.tomGET = function tomGET (req, res, next) {
  var code = req.swagger.params['code'].value;
  var kana = req.swagger.params['kana'].value;
  var name = req.swagger.params['name'].value;
  var phonenumber = req.swagger.params['phonenumber'].value;
  Tom.tomGET(code,kana,name,phonenumber)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
