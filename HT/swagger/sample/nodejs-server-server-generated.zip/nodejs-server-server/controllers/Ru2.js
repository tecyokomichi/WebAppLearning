'use strict';

var utils = require('../utils/writer.js');
var Ru2 = require('../service/Ru2Service');

module.exports.getRu2ById = function getRu2ById (req, res, next) {
  var ru2Id = req.swagger.params['ru2Id'].value;
  Ru2.getRu2ById(ru2Id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
