'use strict';

var utils = require('../utils/writer.js');
var Js7ru2 = require('../service/Js7ru2Service');

module.exports.getJs7Ru2ById = function getJs7Ru2ById (req, res, next) {
  var js7ru2Id = req.swagger.params['js7ru2Id'].value;
  Js7ru2.getJs7Ru2ById(js7ru2Id)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
