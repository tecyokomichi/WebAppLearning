'use strict';

var utils = require('../utils/writer.js');
var Users = require('../service/UsersService');

module.exports.loginUser = function loginUser (req, res, next) {
  var userId = req.swagger.params['userId'].value;
  var password = req.swagger.params['password'].value;
  Users.loginUser(userId,password)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
